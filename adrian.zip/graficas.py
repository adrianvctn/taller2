
# coding: utf-8

# In[7]:


get_ipython().magic(u'matplotlib inline')
import numpy as np
import matplotlib.pyplot as plt


# In[41]:

def f(x, e):
    return ((e ** x)-(e ** -x))/((e ** x)+(e ** -x))


# In[42]:

plt.plot(x, f(x, e), '--')
plt.xlabel("Valor x")
plt.ylabel("Funcion f(x)")
plt.grid(True)


# In[43]:

def escalon(x, c):
    return np.piecewise(x, [x < 0, x > 0], [0, 1])


# In[44]:

c = np.linspace(0, 5)


# In[64]:

plt.plot(x, f(x,c))
plt.axis([x[0], x[-1], -0.1, 1.5])
plt.grid(True)
z=arange


# In[46]:

sigma=0.01
x = np.linspace(-5,5)
e = np.e
pi = np.pi


# In[47]:

x = np.linspace(-200, 200)


# In[48]:

def f(x):
    return (1/np.sqrt(2*pi*sigma**2))*(e**-((x**2)/2*(sigma**2)))


# In[49]:

plt.plot(x, f(x))


# In[51]:

get_ipython().magic(u'matplotlib inline')
import numpy as np
import matplotlib.pyplot as plt


# In[52]:

x = np.linspace(-5, 5)
e = np.e


# In[53]:

def f(x, e):
    return ((e ** x)-(e ** -x))/((e ** x)+(e ** -x))


# In[54]:

plt.plot(x, f(x, e), 'o')
plt.xlabel("Valor x")
plt.ylabel("Funcion f(x)")
plt.grid(True)


# In[ ]:



